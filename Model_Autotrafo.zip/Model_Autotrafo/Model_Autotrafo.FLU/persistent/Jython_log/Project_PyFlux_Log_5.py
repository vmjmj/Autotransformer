#! Flux3D 21.2


# Your project log file has become too 
# large and it is unsafe to open in Flux.
# It has been archived as C:\Users\ALUMNO\Desktop\VJFC\ATT\ATT\test\TV_SC_LV_OC_HV_9.4KV.FLU\persistent\Jython_log\Project_PyFlux_Log_4.py.
# If needed, consider opening it in a high 
# performance dedicated editor.

saveProjectAs('TV_SC_LV_OC_HV_9.4KV.FLU')

displayArrows()

displayIsovalues()

displayIsovalues()

displayArrows()

displayIsovalues()

displayIsovalues()

displayArrows()

lastInstance = ComputePhysic(name='ComputePhysic_6', formula=['Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

exportCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log1.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log1.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

CoilCircular['RV'].deleteForce()
CoilCircular[ALL].setVisible()

Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)'])

Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='4847'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_3', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

lastInstance = ComputePhysic(name='ComputePhysic_4', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_5'


DeleteAllResults(deletePostprocessingResults='yes')

exportCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log2.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log2.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = CoilCircular(name='RV',
             strandedCoil=CoilConductor['RV'],
             turnNumber='100',
             seriesOrParallel=AllInSeries(),
             coilDuplicationBySymmetriesPeriodicities=CoilDuplication(),
             coordSys=CoordSys['XYZ1'],
             center=['0',
                     '0',
                     '10.4375'],
             radius='30.6875',
             section=ComposedCoilRectangularSection(height='20.125',
                                                    width='4'),
             color=Color['Magenta'],
             visibility=Visibility['INVISIBLE'])

CoilCircular['RV'].setVisible()

CoilConductor['RV'].resistanceFormula='0.0034625'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_3', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'EMag(1_DOMAIN)'])

Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['RV'].turnNumber='10'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_4', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_5'


Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['RV'].turnNumber='100'


CoilConductor['RV'].resistanceFormula='0.108739'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_5', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_6'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['TV'].resistanceFormula='0.020274'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_6', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_7'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['TV'].resistanceFormula='0.023927'


CoilConductor['HV'].resistanceFormula='0.388088'


CoilConductor['LV'].resistanceFormula='0.324181'


exportCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log3.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log3.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

CoilCircular['RV'].deleteForce()
Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_7', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_8'


lastInstance = ComputePhysic(name='ComputePhysic_8', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['LV'].resistanceFormula='0.274690'


CoilConductor['HV'].resistanceFormula='0.328840'


CoilConductor['TV'].resistanceFormula='0.020274'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_9', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_10'


Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='5000'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_10', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_11'


lastInstance = ComputePhysic(name='ComputePhysic_11', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'EMag(1_DOMAIN)                                                                  '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_12'


DeleteAllResults(deletePostprocessingResults='yes')

exportCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log4.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='TV_SC_LV_OC_HV_9.4KV_log4.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = CoilCircular(name='RV',
             strandedCoil=CoilConductor['TV'],
             turnNumber='104',
             seriesOrParallel=AllInSeries(),
             coilDuplicationBySymmetriesPeriodicities=CoilDuplication(),
             coordSys=CoordSys['XYZ1'],
             center=['0',
                     '0',
                     '10.4375'],
             radius='30.6875',
             section=ComposedCoilRectangularSection(height='20.125',
                                                    width='4'),
             color=Color['Blue'],
             visibility=Visibility['VISIBLE'])

startMacroTransaction()
Coil['RV'].strandedCoil=CoilConductor['RV']

Coil['RV'].turnNumber='100'

Coil['RV'].color=Color['Magenta']

endMacroTransaction()

CoilConductor['RV'].resistanceFormula='0.064625'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='1', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)'])

Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='4847'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_2'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['RV'].resistanceFormula='0.1004625'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_3'


lastInstance = ComputePhysic(name='ComputePhysic_3', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_4'


Scenario['REFERENCEVALUES'].deleteAllResults()

Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_4', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_5'


lastInstance = ComputePhysic(name='ComputePhysic_5', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_6'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['RV'].resistanceFormula='0.2'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_6', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_7'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['RV'].resistanceFormula='0.034625'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_7', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_8'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['RV'].resistanceFormula='0.0034625'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_8', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_9'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['RV'].resistanceFormula='0.034625'


Coil['RV'].turnNumber='90'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_9', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_10'


Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['RV'].turnNumber='75'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_10', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_11'


Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='5060'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_11', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_12'


Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['RV'].turnNumber='80'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_12', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_13'


Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['RV'].turnNumber='85'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_13', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_14'


Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['RV'].turnNumber='100'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_9.4KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_14', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'Mod(U(RV))/Sqrt(2)                                                              ', 'Mod(I(RV))/Sqrt(2)                                                              ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_15'


Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='5427'


