#! Flux3D 21.2
#! Fri Jul 08 23:07:31 CDT 2022 loadProject('C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

exportCircuit(filename='7_SC_log1.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='7_SC_log1.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = CoilCircular(name='RV_1',
             strandedCoil=CoilConductor['RV_1'],
             turnNumber='100',
             seriesOrParallel=AllInSeries(),
             coilDuplicationBySymmetriesPeriodicities=CoilDuplication(),
             coordSys=CoordSys['XYZ1'],
             center=['0',
                     '0',
                     '10.4375'],
             radius='30.6875',
             section=ComposedCoilRectangularSection(height='20.125',
                                                    width='4'),
             color=Color['Blue'],
             visibility=Visibility['INVISIBLE'])

startMacroTransaction()
CoilCircular[ALL].visibility=Visibility['VISIBLE']

Coil['RV_1'].color=Color['Magenta']

endMacroTransaction()

exportCircuit(filename='7_SC_log2.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='7_SC_log2.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

Coil['RV_1'].name='RV'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

displayIsovalues()

CoilCircular[ALL].setInvisible()

RegionFace['TANK'].setVisible()

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)', 'EMag(1_DOMAIN)'])

startMacroTransaction()
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_3'

ComputePhysicTransient['ComputePhysic'].formula=['Mod(U(HV))/sqrt(2)',
                                                 'Mod(I(HV))/sqrt(2)',
                                                 'Mod(U(LV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'Mod(U(TV))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)',
                                                 'Mod(U(RV))/sqrt(2)',
                                                 'Mod(I(RV))/sqrt(2)',
                                                 'EMag(1_DOMAIN)']

endMacroTransaction()

lastInstance = ComputePhysic(name='ComputePhysic_3', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)', 'EMag(1_DOMAIN)', 'EMag(S_TANK)'])

lastInstance = ComputePhysic(name='ComputePhysic_4', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)', 'EMag(1_DOMAIN)'])

lastInstance = ComputePhysic(name='ComputePhysic_5', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(RV))/sqrt(2)', 'Mod(I(RV))/sqrt(2)', 'EMag(1_DOMAIN)'])

startMacroTransaction()
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_6'

ComputePhysicTransient['ComputePhysic'].formula=['Mod(U(HV))/sqrt(2)',
                                                 'Mod(I(HV))/sqrt(2)',
                                                 'Mod(U(LV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'Mod(U(TV))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)',
                                                 'Mod(U(RV))/sqrt(2)',
                                                 'Mod(I(RV))/sqrt(2)',
                                                 'EMag(1_DOMAIN)']

endMacroTransaction()

displayArrows()

displayIsovalues()

saveProject()

#! Thu Jul 14 12:55:54 CDT 2022 loadProject('C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='12250/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

displayArrows()

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='14250/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='14850/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='14950/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='15000/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

startMacroTransaction()
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_2'

ComputePhysicTransient['ComputePhysic'].formula=['Mod(I(HV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)']

endMacroTransaction()

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='15200/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='15400/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'EMag(1_DOMAIN)'])

saveProjectAs('TV_LV_SC_HV_15.FLU')

displayArrows()

displayIsovalues()

displayArrows()

saveProjectAs('TV_SC_LV_OC_HV_230KV.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

Resistor['RESISTOR_LOAD'].resistance='1E9'


Resistor['RESISTOR_LOAD'].resistance='1E6'


VoltageSource['VOLTAGESOURCE_1'].rmsModulus='230000/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_230KV.FLU')

displayIsovalues()

displayIsovalues()

displayArrows()

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['EMag(1_DOMAIN)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['EMag(1_DOMAIN)                                                                  ', 'Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='15400/Sqrt(3)'


Resistor['RESISTOR_LOAD'].resistance='1E-6'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_230KV.FLU')

displayArrows()

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['EMag(1_DOMAIN)', 'Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['EMag(1_DOMAIN)', 'Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

Resistor['RESISTOR_LOAD'].resistance='1E6'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_230KV.FLU')

displayArrows()

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'EMag(1_DOMAIN)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='12400/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_230KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='8400/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_230KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

DeleteAllResults(deletePostprocessingResults='yes')

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='9400/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='TV_SC_LV_OC_HV_230KV.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

startMacroTransaction()
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_2'

ComputePhysicTransient['ComputePhysic'].formula=['Mod(I(HV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)']

endMacroTransaction()

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_3', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'EMag(1_DOMAIN)'])

lastInstance = ComputePhysic(name='ComputePhysic_4', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'EMag(1_DOMAIN)', 'Mod(U(TV))/sqrt(2)'])

lastInstance = ComputePhysic(name='ComputePhysic_5', formula=['Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'EMag(1_DOMAIN)', 'Mod(U(TV))/sqrt(2)', 'Mod(U(RESISTOR_TV))/sqrt(2)'])

displayArrows()

displayIsovalues()

displayArrows()

displayArrows()

displayIsovalues()

