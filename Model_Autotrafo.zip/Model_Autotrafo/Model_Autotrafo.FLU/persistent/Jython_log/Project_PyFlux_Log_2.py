saveProjectAs('7_OC.FLU')

#! Mon May 16 00:22:38 CDT 2022 loadProject('C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_OC.FLU')

saveProject()

CoilCircular[ALL].setVisible()

displayIsovalues()

DeleteAllResults(deletePostprocessingResults='yes')

Volume[11].setInvisible()

saveProject()

#! Mon May 16 15:08:13 CDT 2022 loadProject('C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_OC.FLU')

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

CoilCircular[ALL].setVisible()

checkMesh()

Point[ALL].setVisible()

Line[ALL].setVisible()

FaceAutomatic[ALL].setVisible()

Volume[ALL].setVisible()

Volume[7].setInvisible()

LineSegment[92].setInvisible()

LineSegment[91].setInvisible()

LineSegment[90].setInvisible()

LineSegment[89].setInvisible()

LineSegment[88].setInvisible()

LineSegment[86].setInvisible()

LineSegment[85].setInvisible()

LineSegment[84].setInvisible()

LineSegment[97].setInvisible()

LineSegment[96].setInvisible()

LineSegment[95].setInvisible()

LineSegment[94].setInvisible()

LineSegment[93].setInvisible()

LineSegment[78].setInvisible()

LineExtruded[70,71].setInvisible()

LineSegment[65].setInvisible()

Volume[1,2,3,4,5,6].setInvisible()

Volume[ALL].setVisible()

FaceAutomatic[63].setInvisible()

FaceAutomatic[58].setInvisible()

FaceAutomatic[ALL].setVisible()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

FaceAutomatic[58].setInvisible()

FaceAutomatic[58,40].setInvisible()

FaceAutomatic[60].setInvisible()

FaceAutomatic[44].setInvisible()

FaceAutomatic[11].setInvisible()

Face[60].visibility=Visibility['VISIBLE']


FaceAutomatic[ALL].setVisible()

FaceAutomatic[44].setInvisible()

FaceAutomatic[11].setInvisible()

FaceAutomatic[40,60].setInvisible()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_OC.FLU')

displayIsovalues()

CoilCircular[ALL].setInvisible()

FaceAutomatic[ALL].setVisible()

Volume[ALL].setVisible()

displayIsovalues()

displayIsovalues()

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'PowerP(HV)', 'PowerS(HV)', 'PjouleCC(HV)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'PowerP(LV)', 'PowerS(LV)', 'PjouleCC(LV)', 'Mod(U(RV_1))/sqrt(2)', 'Mod(I(RV_1))/sqrt(2)', 'PowerP(RV_1)', 'PowerS(RV_1)', 'PjouleCC(RV_1)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'PowerP(TV)', 'PowerS(TV)', 'PjouleCC(TV)', 'Mod(U(RESISTOR_LOAD))/sqrt(2)', 'Mod(I(RESISTOR_LOAD))/sqrt(2)', 'PowerP(RESISTOR_LOAD)', 'PowerS(RESISTOR_LOAD)', 'Res(RESISTOR_LOAD)', 'PjouleR(RESISTOR_LOAD)', 'Mod(U(RESISTOR_TV))/sqrt(2)', 'Mod(I(RESISTOR_TV))/sqrt(2)', 'PowerP(RESISTOR_TV)', 'PowerS(RESISTOR_TV)', 'Res(RESISTOR_TV)', 'PjouleR(RESISTOR_TV)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'Mod(I(VOLTAGESOURCE_1))/sqrt(2)', 'PowerP(VOLTAGESOURCE_1)', 'PowerS(VOLTAGESOURCE_1)', 'EMag(V_CORE)'])

saveProject()

startMacroTransaction()
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_2'

ComputePhysicTransient['ComputePhysic'].formula=['Mod(U(HV))/sqrt(2)',
                                                 'Mod(I(HV))/sqrt(2)',
                                                 'PowerP(HV)',
                                                 'PowerS(HV)',
                                                 'PjouleCC(HV)',
                                                 'Mod(U(LV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'PowerP(LV)',
                                                 'PowerS(LV)',
                                                 'PjouleCC(LV)',
                                                 'Mod(U(RV_1))/sqrt(2)',
                                                 'Mod(I(RV_1))/sqrt(2)',
                                                 'PowerP(RV_1)',
                                                 'PowerS(RV_1)',
                                                 'PjouleCC(RV_1)',
                                                 'Mod(U(TV))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)',
                                                 'PowerP(TV)',
                                                 'PowerS(TV)',
                                                 'PjouleCC(TV)',
                                                 'Mod(U(RESISTOR_LOAD))/sqrt(2)',
                                                 'Mod(I(RESISTOR_LOAD))/sqrt(2)',
                                                 'PowerP(RESISTOR_LOAD)',
                                                 'PowerS(RESISTOR_LOAD)',
                                                 'Res(RESISTOR_LOAD)',
                                                 'PjouleR(RESISTOR_LOAD)',
                                                 'Mod(U(RESISTOR_TV))/sqrt(2)',
                                                 'Mod(I(RESISTOR_TV))/sqrt(2)',
                                                 'PowerP(RESISTOR_TV)',
                                                 'PowerS(RESISTOR_TV)',
                                                 'Res(RESISTOR_TV)',
                                                 'PjouleR(RESISTOR_TV)',
                                                 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)',
                                                 'Mod(I(VOLTAGESOURCE_1))/sqrt(2)',
                                                 'PowerP(VOLTAGESOURCE_1)',
                                                 'PowerS(VOLTAGESOURCE_1)',
                                                 'EMag(V_CORE)']

endMacroTransaction()

displayIsovalues()

displayArrows()

RegionVolume['FRAME'].setInvisible()

displayArrows()

displayIsovalues()

RegionVolume['FRAME'].setVisible()

SpatialCurve(name='SpatialCurve_1',
             compoundPath=CompoundPath['PIERNA_CENTRAL'],
             formula=['ModV(ModC(B))'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

displayIsovalues()

RegionFace['TANK'].setInvisible()

RegionVolume['CORE'].setInvisible()

RegionVolume['CORE'].setVisible()

displayIsovalues()

displayIsovalues()

Scenario['REFERENCEVALUES'].deleteAllResults()

Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_OC.FLU')

Scenario['REFERENCEVALUES'].deleteAllResults()

checkMesh()

Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_OC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'PowerP(HV)                                                                      ', 'PowerS(HV)                                                                      ', 'PjouleCC(HV)                                                                    ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'PowerP(LV)                                                                      ', 'PowerS(LV)                                                                      ', 'PjouleCC(LV)                                                                    ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'PowerP(RV_1)                                                                    ', 'PowerS(RV_1)                                                                    ', 'PjouleCC(RV_1)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'PowerP(TV)                                                                      ', 'PowerS(TV)                                                                      ', 'PjouleCC(TV)                                                                    ', 'Mod(U(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'Mod(I(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'PowerP(RESISTOR_LOAD)                                                           ', 'PowerS(RESISTOR_LOAD)                                                           ', 'Res(RESISTOR_LOAD)                                                              ', 'PjouleR(RESISTOR_LOAD)                                                          ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(I(RESISTOR_TV))/Sqrt(2)                                                     ', 'PowerP(RESISTOR_TV)                                                             ', 'PowerS(RESISTOR_TV)                                                             ', 'Res(RESISTOR_TV)                                                                ', 'PjouleR(RESISTOR_TV)                                                            ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'Mod(I(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'PowerP(VOLTAGESOURCE_1)                                                         ', 'PowerS(VOLTAGESOURCE_1)                                                         ', 'EMag(V_CORE)                                                                    '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_3'


saveProject()

