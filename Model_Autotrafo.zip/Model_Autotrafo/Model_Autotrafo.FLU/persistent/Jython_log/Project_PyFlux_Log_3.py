saveProjectAs('7_SC.FLU')

#! Tue May 17 11:57:18 CDT 2022 loadProject('C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

Scenario['REFERENCEVALUES'].deleteAllResults()

Resistor['RESISTOR_LOAD'].resistance='1E-6'


Resistor['RESISTOR_TV'].resistance='1E-6'


VoltageSource['VOLTAGESOURCE_1'].rmsModulus='23000/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

displayIsovalues()

lastInstance = ComputePhysic(name='ComputePhysic_3', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'PowerP(HV)                                                                      ', 'PowerS(HV)                                                                      ', 'PjouleCC(HV)                                                                    ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'PowerP(LV)                                                                      ', 'PowerS(LV)                                                                      ', 'PjouleCC(LV)                                                                    ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'PowerP(RV_1)                                                                    ', 'PowerS(RV_1)                                                                    ', 'PjouleCC(RV_1)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'PowerP(TV)                                                                      ', 'PowerS(TV)                                                                      ', 'PjouleCC(TV)                                                                    ', 'Mod(U(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'Mod(I(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'PowerP(RESISTOR_LOAD)                                                           ', 'PowerS(RESISTOR_LOAD)                                                           ', 'Res(RESISTOR_LOAD)                                                              ', 'PjouleR(RESISTOR_LOAD)                                                          ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(I(RESISTOR_TV))/Sqrt(2)                                                     ', 'PowerP(RESISTOR_TV)                                                             ', 'PowerS(RESISTOR_TV)                                                             ', 'Res(RESISTOR_TV)                                                                ', 'PjouleR(RESISTOR_TV)                                                            ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'Mod(I(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'PowerP(VOLTAGESOURCE_1)                                                         ', 'PowerS(VOLTAGESOURCE_1)                                                         ', 'EMag(V_CORE)                                                                    '])

lastInstance = ComputePhysic(name='ComputePhysic_4', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'PowerP(HV)                                                                      ', 'PowerS(HV)                                                                      ', 'PjouleCC(HV)                                                                    ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'PowerP(LV)                                                                      ', 'PowerS(LV)                                                                      ', 'PjouleCC(LV)                                                                    ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'PowerP(RV_1)                                                                    ', 'PowerS(RV_1)                                                                    ', 'PjouleCC(RV_1)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'PowerP(TV)                                                                      ', 'PowerS(TV)                                                                      ', 'PjouleCC(TV)                                                                    ', 'Mod(U(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'Mod(I(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'PowerP(RESISTOR_LOAD)                                                           ', 'PowerS(RESISTOR_LOAD)                                                           ', 'Res(RESISTOR_LOAD)                                                              ', 'PjouleR(RESISTOR_LOAD)                                                          ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(I(RESISTOR_TV))/Sqrt(2)                                                     ', 'PowerP(RESISTOR_TV)                                                             ', 'PowerS(RESISTOR_TV)                                                             ', 'Res(RESISTOR_TV)                                                                ', 'PjouleR(RESISTOR_TV)                                                            ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'Mod(I(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'PowerP(VOLTAGESOURCE_1)                                                         ', 'PowerS(VOLTAGESOURCE_1)                                                         ', 'EMag(V_CORE)                                                                    '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_5'


Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='2300/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

displayIsovalues()

lastInstance = ComputePhysic(name='ComputePhysic_5', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'PowerP(HV)                                                                      ', 'PowerS(HV)                                                                      ', 'PjouleCC(HV)                                                                    ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'PowerP(LV)                                                                      ', 'PowerS(LV)                                                                      ', 'PjouleCC(LV)                                                                    ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'PowerP(RV_1)                                                                    ', 'PowerS(RV_1)                                                                    ', 'PjouleCC(RV_1)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'PowerP(TV)                                                                      ', 'PowerS(TV)                                                                      ', 'PjouleCC(TV)                                                                    ', 'Mod(U(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'Mod(I(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'PowerP(RESISTOR_LOAD)                                                           ', 'PowerS(RESISTOR_LOAD)                                                           ', 'Res(RESISTOR_LOAD)                                                              ', 'PjouleR(RESISTOR_LOAD)                                                          ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(I(RESISTOR_TV))/Sqrt(2)                                                     ', 'PowerP(RESISTOR_TV)                                                             ', 'PowerS(RESISTOR_TV)                                                             ', 'Res(RESISTOR_TV)                                                                ', 'PjouleR(RESISTOR_TV)                                                            ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'Mod(I(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'PowerP(VOLTAGESOURCE_1)                                                         ', 'PowerS(VOLTAGESOURCE_1)                                                         ', 'EMag(V_CORE)                                                                    '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_6'


Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='11500/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_6', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'PowerP(HV)                                                                      ', 'PowerS(HV)                                                                      ', 'PjouleCC(HV)                                                                    ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'PowerP(LV)                                                                      ', 'PowerS(LV)                                                                      ', 'PjouleCC(LV)                                                                    ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'PowerP(RV_1)                                                                    ', 'PowerS(RV_1)                                                                    ', 'PjouleCC(RV_1)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'PowerP(TV)                                                                      ', 'PowerS(TV)                                                                      ', 'PjouleCC(TV)                                                                    ', 'Mod(U(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'Mod(I(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'PowerP(RESISTOR_LOAD)                                                           ', 'PowerS(RESISTOR_LOAD)                                                           ', 'Res(RESISTOR_LOAD)                                                              ', 'PjouleR(RESISTOR_LOAD)                                                          ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(I(RESISTOR_TV))/Sqrt(2)                                                     ', 'PowerP(RESISTOR_TV)                                                             ', 'PowerS(RESISTOR_TV)                                                             ', 'Res(RESISTOR_TV)                                                                ', 'PjouleR(RESISTOR_TV)                                                            ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'Mod(I(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'PowerP(VOLTAGESOURCE_1)                                                         ', 'PowerS(VOLTAGESOURCE_1)                                                         ', 'EMag(V_CORE)                                                                    '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_7'


Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='12000/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_7', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'PowerP(HV)                                                                      ', 'PowerS(HV)                                                                      ', 'PjouleCC(HV)                                                                    ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'PowerP(LV)                                                                      ', 'PowerS(LV)                                                                      ', 'PjouleCC(LV)                                                                    ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'PowerP(RV_1)                                                                    ', 'PowerS(RV_1)                                                                    ', 'PjouleCC(RV_1)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'PowerP(TV)                                                                      ', 'PowerS(TV)                                                                      ', 'PjouleCC(TV)                                                                    ', 'Mod(U(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'Mod(I(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'PowerP(RESISTOR_LOAD)                                                           ', 'PowerS(RESISTOR_LOAD)                                                           ', 'Res(RESISTOR_LOAD)                                                              ', 'PjouleR(RESISTOR_LOAD)                                                          ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(I(RESISTOR_TV))/Sqrt(2)                                                     ', 'PowerP(RESISTOR_TV)                                                             ', 'PowerS(RESISTOR_TV)                                                             ', 'Res(RESISTOR_TV)                                                                ', 'PjouleR(RESISTOR_TV)                                                            ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'Mod(I(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'PowerP(VOLTAGESOURCE_1)                                                         ', 'PowerS(VOLTAGESOURCE_1)                                                         ', 'EMag(V_CORE)                                                                    '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_8'


Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='12250/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_8', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'PowerP(HV)                                                                      ', 'PowerS(HV)                                                                      ', 'PjouleCC(HV)                                                                    ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'PowerP(LV)                                                                      ', 'PowerS(LV)                                                                      ', 'PjouleCC(LV)                                                                    ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'PowerP(RV_1)                                                                    ', 'PowerS(RV_1)                                                                    ', 'PjouleCC(RV_1)                                                                  ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(TV))/Sqrt(2)                                                              ', 'PowerP(TV)                                                                      ', 'PowerS(TV)                                                                      ', 'PjouleCC(TV)                                                                    ', 'Mod(U(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'Mod(I(RESISTOR_LOAD))/Sqrt(2)                                                   ', 'PowerP(RESISTOR_LOAD)                                                           ', 'PowerS(RESISTOR_LOAD)                                                           ', 'Res(RESISTOR_LOAD)                                                              ', 'PjouleR(RESISTOR_LOAD)                                                          ', 'Mod(U(RESISTOR_TV))/Sqrt(2)                                                     ', 'Mod(I(RESISTOR_TV))/Sqrt(2)                                                     ', 'PowerP(RESISTOR_TV)                                                             ', 'PowerS(RESISTOR_TV)                                                             ', 'Res(RESISTOR_TV)                                                                ', 'PjouleR(RESISTOR_TV)                                                            ', 'Mod(U(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'Mod(I(VOLTAGESOURCE_1))/Sqrt(2)                                                 ', 'PowerP(VOLTAGESOURCE_1)                                                         ', 'PowerS(VOLTAGESOURCE_1)                                                         ', 'EMag(V_CORE)                                                                    '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_9'


displayIsovalues()

displayIsovalues()

displayArrows()

RegionVolume['FRAME'].setInvisible()

lastInstance = ComputePhysic(name='ComputePhysic_9', formula=['Mod(U(HV))/sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(U(RV_1))/sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'Mod(I(RV_1))/sqrt(2)', 'Mod(I(TV))/sqrt(2)'])

startMacroTransaction()
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_10'

ComputePhysicTransient['ComputePhysic'].formula=['Mod(U(HV))/sqrt(2)',
                                                 'Mod(U(LV))/sqrt(2)',
                                                 'Mod(U(RV_1))/sqrt(2)',
                                                 'Mod(U(TV))/sqrt(2)',
                                                 'Mod(I(HV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'Mod(I(RV_1))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)']

endMacroTransaction()

RegionFace['TANK'].setVisible()

saveProject()

saveProject()

RegionFace['TANK'].setInvisible()

displayArrows()

displayIsolines()

displayIsolines()

Scenario['REFERENCEVALUES'].deleteAllResults()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='13250/Sqrt(3)'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_10', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'Mod(I(TV))/Sqrt(2)                                                              '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_11'


Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['TV'].turnNumber='114'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_11', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'Mod(I(TV))/Sqrt(2)                                                              '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_12'


lastInstance = ComputePhysic(name='ComputePhysic_12', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'Mod(I(TV))/Sqrt(2)                                                              '])

lastInstance = ComputePhysic(name='ComputePhysic_13', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'Mod(I(TV))/Sqrt(2)                                                              '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_14'


Scenario['REFERENCEVALUES'].deleteAllResults()

Coil['TV'].turnNumber='104'


CoilConductor['TV'].resistanceFormula='0.02'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_14', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'Mod(I(TV))/Sqrt(2)                                                              '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_15'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductor['TV'].resistanceFormula='0.023927'


Scenario['REFERENCEVALUES'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7_SC.FLU')

lastInstance = ComputePhysic(name='ComputePhysic_15', formula=['Mod(U(HV))/Sqrt(2)                                                              ', 'Mod(U(LV))/Sqrt(2)                                                              ', 'Mod(U(RV_1))/Sqrt(2)                                                            ', 'Mod(U(TV))/Sqrt(2)                                                              ', 'Mod(I(HV))/Sqrt(2)                                                              ', 'Mod(I(LV))/Sqrt(2)                                                              ', 'Mod(I(RV_1))/Sqrt(2)                                                            ', 'Mod(I(TV))/Sqrt(2)                                                              '])

ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_16'


Scenario['REFERENCEVALUES'].deleteAllResults()

CoilConductorCircuit['RV_1'].delete()
exportCircuit(filename='7_SC_log1.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='7_SC_log1.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

CoilCircular['RV'].deleteForce()
