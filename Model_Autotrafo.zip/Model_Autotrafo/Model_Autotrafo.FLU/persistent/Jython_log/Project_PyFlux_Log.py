#! Flux3D 22.0
#! Wed Nov 30 18:55:20 CST 2022 loadProject('C:/Users/victorjimenez/Desktop/test/TV_SC_LV_OC_HV_9.4KV.FLU')

saveProjectAs('../Autotransfo/Z_alta_terciario.FLU')

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

RegionFace['TANK'].setVisible()

Scenario['REFERENCEVALUES'].deleteAllResults()

checkMesh()

checkMesh()

meshVolumes()

RegionFace['TANK'].setInvisible()

RegionVolume['AIR'].setInvisible()

RegionFace['TANK'].setInvisible()

VoltageSource['VOLTAGESOURCE_1'].rmsModulus='5.07e3'


Scenario['REFERENCEVALUES'].solve(projectName='../Autotransfo/Z_alta_terciario.FLU')

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

displayIsovalues()

RegionFace['TANK'].setVisible()

displayIsovalues()

displayArrows()

displayArrows()

displayIsovalues()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

displayIsovalues()

saveProject()

#! Wed Nov 30 19:22:11 CST 2022 loadProject('C:/Users/victorjimenez/Desktop/Autotransfo/Z_alta_terciario.FLU')

displayIsovalues()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

displayIsovalues()

RegionVolume['CORE'].setVisible()

RegionVolume['FRAME'].setVisible()

RegionFace['TANK'].setVisible()

lastInstance = IsovalueSpatialGroup(name='ISOVAL_1',
                     formula='Real(B)',
                     forceVisibility='yes',
                     smoothValues='yes',
                     regionInternalExternal='Automatic',
                     internalComputation='no',
                     regionType='volumeRegion',
                     group=[Groupspatial['V_CORE'],
                            Groupspatial['V_FRAME']])

IsovalueSpatialGroup['ISOVAL_1'].delete()
lastInstance = IsovalueSpatialGroup(name='ISOVAL_1',
                     formula='Real(B)',
                     forceVisibility='yes',
                     smoothValues='yes',
                     regionInternalExternal='Automatic',
                     internalComputation='no',
                     regionType='volumeRegion',
                     group=[Groupspatial['S_TANK']])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

displayIsovalues()

displayIsovalues()

IsovalueSpatialGroup['1_ISOVAL_DOMAIN'].displayIsovalue()

IsovalueSpatialGroup['ISOVAL_1'].delete()
displayIsovalues()

displayIsovalues()

displayIsovalues()

saveProject()

#! Mon Jan 09 12:32:26 CST 2023 loadProject('C:/Users/victorjimenez/Desktop/Autotransfo/Z_alta_terciario.FLU')

saveProjectAs('../Model_Autotrafo/Model_Autotrafo.FLU')

Scenario['REFERENCEVALUES'].deleteAllResults()

saveProject()

#! Mon Jan 09 12:35:57 CST 2023 loadProject('C:/Users/victorjimenez/Desktop/Model_Autotrafo/Model_Autotrafo.FLU')

Scenario['REFERENCEVALUES'].delete()
saveProject()

