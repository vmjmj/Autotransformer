#! Flux3D 21.2
newProject()

GeomMeshOptions[1].methodAutomaticMeshVolume=OptimizeMeshGemsActivated(level=OptimizationStandard())

openModelerContext()

closeModelerContext()

startMacroTransaction()
CoordSys['XYZ1'].parentCoordSys=GlobalUnits(lengthUnit=LengthUnit['INCH'],
                                            angleUnit=AngleUnit['DEGREE'])

CoordSys['Z_ON_OX'].parentCoordSys=GlobalUnits(lengthUnit=LengthUnit['INCH'],
                                               angleUnit=AngleUnit['DEGREE'])

CoordSys['Z_ON_OY'].parentCoordSys=GlobalUnits(lengthUnit=LengthUnit['INCH'],
                                               angleUnit=AngleUnit['DEGREE'])

endMacroTransaction()

lastInstance = SymmetryXYplane(physicalType=SymmetryNormalMagFields(),
                position='0')

lastInstance = SymmetryYZplane(physicalType=SymmetryTangentMagFields(),
                position='0')

lastInstance = SymmetryZXplane(physicalType=SymmetryTangentMagFields(),
                position='0')

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '0',
                      '0'],
                 nature=Nature['STANDARD'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '0',
                      '65.90625'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '50.75',
                      '65.90625'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '50.75',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '0',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '13.875',
                      '13.875'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '36.875',
                      '13.875'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '13.875',
                      '52.03125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '36.875',
                      '52.03125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '0',
                      '65.71875'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '50.375',
                      '65.71875'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '50.375',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '13.5',
                      '52.21875'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '36.875',
                      '52.21875'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '36.875',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

Point[15].uvw=['4.284',
               '36.875',
               '13.5']


lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '13.5',
                      '13.5'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[2],
                      Point[1]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[1],
                      Point[4]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[4],
                      Point[3]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[3],
                      Point[2]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[10],
                      Point[5]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[10],
                      Point[11]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[11],
                      Point[12]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[12],
                      Point[5]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[1],
                      Point[6]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[6],
                      Point[8]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[8],
                      Point[2]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[8],
                      Point[9]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[9],
                      Point[3]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[9],
                      Point[7]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[7],
                      Point[6]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[5],
                      Point[16]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[16],
                      Point[13]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[13],
                      Point[14]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[14],
                      Point[15]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[15],
                      Point[12]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[15],
                      Point[16]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[7],
                      Point[4]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[3],
                      Point[11]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[2],
                      Point[10]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[1],
                      Point[5]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[4],
                      Point[12]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[8],
                      Point[13]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[9],
                      Point[14]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[6],
                      Point[16]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[7],
                      Point[15]],
            nature=Nature['STANDARD'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

LineSegment[2].delete()
LineSegment[8].delete()
LineSegment[21].delete()
LineSegment[15].delete()
startMacroTransaction()
Point[6].uvw=['0',
              '13.875',
              '0']

Point[16].uvw=['4.284',
               '13.5',
               '0']

Point[7].uvw=['0',
              '36.875',
              '0']

Point[15].uvw=['4.284',
               '36.875',
               '0']

endMacroTransaction()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[10],
                      Point[13]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[14],
                      Point[11]],
            nature=Nature['STANDARD'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '0',
                      '64.59375'],
                 nature=Nature['STANDARD'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '0',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '48.125',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '48.125',
                      '64.59375'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '11.25',
                      '53.34375'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '11.25',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '36.875',
                      '53.34375'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '36.875',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[17],
                      Point[21]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[21],
                      Point[22]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[17],
                      Point[18]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[18],
                      Point[22]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[17],
                      Point[10]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[13],
                      Point[21]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[5],
                      Point[18]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[16],
                      Point[22]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[15],
                      Point[24]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[12],
                      Point[19]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[14],
                      Point[23]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[21],
                      Point[23]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[23],
                      Point[20]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[20],
                      Point[11]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[20],
                      Point[19]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[23],
                      Point[24]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[24],
                      Point[19]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[17],
                      Point[20]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '0',
                      '62.15625'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '0',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '43.25',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '43.25',
                      '62.15625'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '6.375',
                      '55.78125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '36.875',
                      '55.78125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '36.875',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '6.375',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[17],
                      Point[25]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[25],
                      Point[29]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[25],
                      Point[26]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[26],
                      Point[32]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[22],
                      Point[32]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[18],
                      Point[26]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[21],
                      Point[29]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[29],
                      Point[32]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[23],
                      Point[30]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[30],
                      Point[28]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[28],
                      Point[20]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[28],
                      Point[25]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[29],
                      Point[30]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[30],
                      Point[31]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[31],
                      Point[27]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[27],
                      Point[19]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[24],
                      Point[31]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[28],
                      Point[27]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

