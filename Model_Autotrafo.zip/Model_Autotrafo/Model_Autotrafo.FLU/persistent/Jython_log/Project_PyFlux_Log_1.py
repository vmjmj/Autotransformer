#! Flux3D 21.2


# Your project log file has become too 
# large and it is unsafe to open in Flux.
# It has been archived as C:\Users\ALUMNO\Desktop\VJFC\ATT\ATT\test\7.FLU\persistent\Jython_log\Project_PyFlux_Log_0.py.
# If needed, consider opening it in a high 
# performance dedicated editor.

saveProjectAs('7.FLU')

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

buildFaces()

buildVolumes()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

saveProject()

saveProject()

#! Sun May 15 19:06:07 CDT 2022 loadProject('C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7.FLU')

lastInstance = MeshLineArithmetic(name='MeshLine_10',
                   color=Color['Grey'],
                   number=10)

LineSegment[4,6,46,58].assignMeshLine(meshLine=MeshLine['MESHLINE_10'])

lastInstance = MeshLineArithmetic(name='MESHLINE_15',
                   color=Color['Grey'],
                   number=15)

LineSegment[1,5,31,49,10,54,21,17,19,14,44,60,3,64,43,7].assignMeshLine(meshLine=MeshLine['MESHLINE_15'])

lastInstance = MeshLineArithmetic(name='MESHLINE_5',
                   color=Color['Grey'],
                   number=5)

LineSegment[9,16,32,22,20,45,13,8,41,11,2,15].assignMeshLine(meshLine=MeshLine['MESHLINE_5'])

lastInstance = MeshLineArithmetic(name='MESHLINE_2',
                   color=Color['Grey'],
                   number=2)

LineSegment[25,35,52,50,51,36,29,30,37,63,61,62,38,26,23,42,57,56,55,39,28,27,34,53,48,47,33,24].assignMeshLine(meshLine=MeshLine['MESHLINE_2'])

lastInstance = MeshLineArithmetic(name='MESHLINE_8',
                   color=Color['Grey'],
                   number=8)

LineSegment[12,18,40,59].assignMeshLine(meshLine=MeshLine['MESHLINE_8'])

LineSegment[12,40,59,18].assignMeshLine(meshLine=MeshLine['MESHLINE_8'])

PointCoordinates[ALL].assignMeshPoint(meshPoint=MeshPoint['SMALL'])

FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

meshLines()

meshFaces()

meshVolumes()

checkMesh()

deleteMesh()

meshDomain()

checkMesh()

deleteMesh()

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.0561',
                      '0',
                      '69.8125'],
                 nature=Nature['STANDARD'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.0561',
                      '0',
                      '55.3125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.0561',
                      '59.875',
                      '55.3125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.0561',
                      '59.875',
                      '69.8125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[34],
                      Point[33]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[33],
                      Point[36]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[36],
                      Point[35]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[35],
                      Point[34]],
            nature=Nature['STANDARD'])

lastInstance = TransfTranslationVector(name='Transf_1',
                        coordSys=CoordSys['XYZ1'],
                        vector=['8.25',
                                '0',
                                '0'])

result = PointCoordinates[33,34,36,35].extrude(transformation=Transf['TRANSF_1'],
        repetitionNumber=1,
        extrusionType='standard')

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[37],
                      Point[39]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[39],
                      Point[40]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[40],
                      Point[38]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[38],
                      Point[37]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

buildFaces()

healGeometry()

buildFaces()

buildVolumes()

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '0',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '64.75',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['44.364',
                      '0',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['44.364',
                      '64.75',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['44.364',
                      '0',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['44.364',
                      '64.75',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['0',
                      '64.75',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[44],
                      Point[45]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[45],
                      Point[47]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[47],
                      Point[46]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[46],
                      Point[44]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[46],
                      Point[48]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[47],
                      Point[49]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[50],
                      Point[49]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[50],
                      Point[45]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[49],
                      Point[48]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[48],
                      Point[26]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[6],
                      Point[7]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[4],
                      Point[50]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[44],
                      Point[2]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

buildFaces()

buildVolumes()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

lastInstance = MeshLineAbsoluteDeviation(name='MeshLine_50',
                          color=Color['Grey'],
                          absoluteDeviationValue=50.0)

LineSegment[88,91,89,92,86,87,84,85,90].assignMeshLine(meshLine=MeshLine['MESHLINE_50'])

LineSegment[88].assignMeshLine(meshLine=MeshLine['MESHLINE_50'])

startMacroTransaction()
MeshLine['MESHLINE_50'] = MeshLineArithmetic(name='MESHLINE_50',
                                             color=Color['Grey'],
                                             number=50)
endMacroTransaction()

LineSegment[88,92,90,89,86,85,91,84,87].assignMeshLine(meshLine=MeshLine['MESHLINE_50'])

lastInstance = MeshLineArithmetic(name='MESHLINE_25',
                   color=Color['Grey'],
                   number=25)

LineSegment[93,94,95,96].assignMeshLine(meshLine=MeshLine['MESHLINE_25'])

FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[1,2,3,4,5,6].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[6].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[8].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[9].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

FaceAutomatic[44].deleteForce()
FaceAutomatic[48].deleteForce()
startMacroTransaction()
Point[33].uvw=['13.06',
               '0',
               '69.8125']

Point[34].uvw=['13.06',
               '0',
               '55.3125']

Point[36].uvw=['13.06',
               '59.875',
               '69.8125']

Point[35].uvw=['13.06',
               '59.875',
               '55.3125']

endMacroTransaction()

buildFaces()

buildVolumes()

Volume[7].deleteForce()
buildFaces()

buildVolumes()

Volume[7].deleteForce()
buildFaces()

buildVolumes()

LineSegment[93].deleteForce()
buildFaces()

buildVolumes()

LineSegment[77].deleteForce()
PointCoordinates[33,34,35,36].deleteForce()
LineSegment[80].deleteForce()
LineSegment[82].deleteForce()
PointCoordinates[41].deleteForce()
PointCoordinates[42].deleteForce()
PointCoordinates[43].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[25],
                      Point[26]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[29],
                      Point[32]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[30],
                      Point[31]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[28],
                      Point[27]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[26],
                      Point[48]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.057',
                      '0',
                      '69.8125'],
                 nature=Nature['STANDARD'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.057',
                      '0',
                      '55.3125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.057',
                      '59.875',
                      '69.8125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.057',
                      '59.875',
                      '55.3125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[33],
                      Point[34]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[33],
                      Point[35]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[35],
                      Point[36]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[36],
                      Point[34]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

result = checkGeometry()

startMacroTransaction()
Point[33].uvw=['13.058',
               '0',
               '69.8125']

Point[34].uvw=['13.058',
               '0',
               '55.3125']

Point[35].uvw=['13.058',
               '59.875',
               '69.8125']

Point[36].uvw=['13.058',
               '59.875',
               '55.3125']

endMacroTransaction()

result = checkGeometry()

result = checkGeometry()

result = LineSegment[66,67,69,68].extrude(transformation=Transf['TRANSF_1'],
        repetitionNumber=1,
        extrusionType='standard',
        buildingOption='Lines')

buildFaces()

buildVolumes()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

checkMesh()

result = checkGeometry()

Face[40].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[1,2,3,4,5,6,7,8,9,11].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[11].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

startMacroTransaction()
FaceAutomatic[40,45,46].visibility=Visibility['INVISIBLE']

FaceAutomatic[40,45,46].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']

endMacroTransaction()

Face[45].visibility=Visibility['VISIBLE']


viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

deleteMesh()

LineSegment[87].deleteForce()
LineSegment[65].deleteForce()
lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '0',
                      '87.88'],
                 nature=Nature['STANDARD'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '0',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '0',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.058',
                      '0',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['21.308',
                      '0',
                      '87.88'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['21.308',
                      '0',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.058',
                      '0',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[26],
                      Point[54]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[54],
                      Point[53]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[53],
                      Point[48]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[44],
                      Point[41]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[41],
                      Point[42]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[42],
                      Point[51]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[51],
                      Point[52]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[52],
                      Point[46]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[52],
                      Point[37]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[43],
                      Point[51]],
            nature=Nature['STANDARD'])

LineSegment[82].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[43],
                      Point[42]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[43],
                      Point[25]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[33],
                      Point[51]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[42],
                      Point[17]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[41],
                      Point[10]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[54],
                      Point[34]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[38],
                      Point[53]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[45],
                      Point[3]],
            nature=Nature['STANDARD'])

buildFaces()

PointCoordinates[54].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[26],
                      Point[53]],
            nature=Nature['STANDARD'])

PointCoordinates[51].delete()
PointCoordinates[51].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[43],
                      Point[52]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[1,2,3,4,5,6,7,8,9,11].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[10].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

FaceAutomatic[40,54,59,62].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


deleteMesh()

LineSegment[49].deleteForce()
lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '0',
                      '55.3125'],
                 nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[51],
                      Point[25]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[51],
                      Point[26]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[1,2,3,4,5,6,9,10,11,8].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

structureFace(face=Face[31],
              points=[Point[17],
                      Point[25],
                      Point[26],
                      Point[18]])

structureFace(face=Face[40],
              points=[Point[26],
                      Point[48],
                      Point[49],
                      Point[50]])

structureFace(face=Face[43],
              points=[Point[26],
                      Point[32],
                      Point[29],
                      Point[25]])

structureFace(face=Face[54],
              points=[Point[34],
                      Point[38],
                      Point[53],
                      Point[26]])

structureFace(face=Face[59],
              points=[Point[46],
                      Point[47],
                      Point[45],
                      Point[44]])

structureFace(face=Face[62],
              points=[Point[52],
                      Point[46],
                      Point[48],
                      Point[53]])

Face[31].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


deleteMesh()

saveProject()

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '0',
                      '55.3125'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

LineSegment[31].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[17],
                      Point[54]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[54],
                      Point[18]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

deleteMesh()

Face[40].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


deleteMesh()

LineSegment[98].deleteForce()
lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '0',
                      '69.8125'],
                 nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[55],
                      Point[25]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[55],
                      Point[33]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[55],
                      Point[43]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[51],
                      Point[34]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

buildFaces()

LineSegment[83].delete()
Point[54].visibility=Visibility['INVISIBLE']


LineSegment[83].deleteForce()
Point[51].uvw=['13.056',
               '0',
               '50']


LineSegment[105].deleteForce()
LineSegment[102].deleteForce()
Point[55].uvw=['13.056',
               '0',
               '70']


LineSegment[99].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[55],
                      Point[33]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[55],
                      Point[43]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[34],
                      Point[51]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[51],
                      Point[26]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

Face[56].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


deleteMesh()

Face[56].meshGenerator=MeshGenerator['NO_MESH']


deleteMesh()

LineSegment[49,102,66,98].assignMeshLine(meshLine=MeshLine['MESHLINE_50'])

meshLines()

deleteMesh()

LineSegment[104].deleteForce()
PointCoordinates[53,51,52,43,42,41].deleteForce()
Point[ALL].setVisible()

PointCoordinates[55].deleteForce()
PointCoordinates[54].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[17],
                      Point[18]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[25],
                      Point[26]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[44],
                      Point[46]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[26],
                      Point[48]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

buildVolumes()

Face[40].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


Point[ALL].assignMeshPoint(meshPoint=MeshPoint['SMALL'])

FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[1,2,3,4,5,6,8,9,10,11].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[7].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

FaceAutomatic[11,40,43].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


GeomMeshOptions[1].methodAutomaticMeshVolume=OptimizeDelaunayMeshInactivated()


GeomMeshOptions[1].methodAutomaticMeshVolume=OptimizeMeshGemsActivated(level=OptimizationStandard())


AidedMesh[1].aidedMeshState=AidedMeshActivated(meshPoint=MeshPointAssigned(type=MeshPointDynamic()),
                                               meshDeviation=MeshDeviationAssignedExcludeIB(type=MeshDeviationExcludeIBRelative(value=0.75)),
                                               meshRelaxation=MeshRelaxation(lineMeshRelaxation=LineMeshRelaxationAssigned(type=LineMeshRelaxationLow()),
                                                                             faceMeshRelaxation=FaceMeshRelaxationAssigned(type=FaceMeshRelaxationLow()),
                                                                             volumeMeshRelaxation=VolumeMeshRelaxationAssigned(type=VolumeMeshRelaxationLow())),
                                               meshShadow=MeshShadowUnassigned())


AidedMesh[1].synchronize()

cleanAllMeshInformation()

meshDomain()

checkMesh()

checkMesh()

checkMesh()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

deleteMesh()

Point[ALL].assignMeshPoint(meshPoint=MeshPoint['SMALL'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

LineSegment[1,5,54,49,21,31,10,17,19,14,44,60,3,64,7,43].assignMeshLine(meshLine=MeshLine['MESHLINE_25'])

LineSegment[12,18,6,46,58,59,4,40].assignMeshLine(meshLine=MeshLine['MESHLINE_15'])

LineSegment[50,16,32,9,22,20,45,61,13,8,41,56,48,15,2,11].assignMeshLine(meshLine=MeshLine['MESHLINE_8'])

LineSegment[63,37,30,28,39,55,62,23,27,34,53,47,33,24,52,35,25,51,36,29,42,57,38,26].assignMeshLine(meshLine=MeshLine['MESHLINE_5'])

LineSegment[78,92,88,94,95,91,90,89,86,85,65,84,96].assignMeshLine(meshLine=MeshLine['MESHLINE_50'])

FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[1,2,3,4,5,6,8,9,10,11].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[7].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

FaceAutomatic[11,40,43].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


meshLines()

deleteMesh()

saveProject()

saveProject()

FaceAutomatic[40,45].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

FaceAutomatic[1,21,2,42,8,10].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


deleteMesh()

cleanAllMeshInformation()

meshDomain()

deleteMesh()

deleteMesh()

startMacroTransaction()
Point[33].uvw=['13.056',
               '0',
               '69.8125']

Point[34].uvw=['13.056',
               '0',
               '55.3125']

endMacroTransaction()

deleteMesh()

LineSegment[49].deleteForce()
LineSegment[66].deleteForce()
startMacroTransaction()
Point[35].uvw=['13.056',
               '59.875',
               '69.8125']

Point[36].uvw=['13.056',
               '59.875',
               '55.3125']

endMacroTransaction()

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[33],
                      Point[25]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[25],
                      Point[34]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[34],
                      Point[26]],
            nature=Nature['STANDARD'])

buildFaces()

result = checkGeometry()

result = checkGeometry()

buildFaces()

healGeometry()

buildFaces()

buildVolumes()

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[37],
                      Point[38]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

buildFaces()

buildVolumes()

Point[ALL].assignMeshPoint(meshPoint=MeshPoint['SMALL'])

FaceAutomatic[ALL].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[1,2,3,4,5,6].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[8].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[9,10,11].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[3],
                      Point[45]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

buildFaces()

buildVolumes()

structureFace(face=Face[30],
              points=[Point[29],
                      Point[21],
                      Point[22],
                      Point[32]])

structureFace(face=Face[36],
              points=[Point[27],
                      Point[19],
                      Point[28],
                      Point[20]])

structureFace(face=Face[37],
              points=[Point[24],
                      Point[31],
                      Point[30],
                      Point[23]])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[32],
                      Point[31]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[27],
                      Point[49]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[22],
                      Point[24]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[16],
                      Point[15]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[12],
                      Point[49]],
            nature=Nature['STANDARD'],
            relaxation=RelaxLine['AIDED_RELAXLINE'])

LineSegment[102].deleteForce()
LineSegment[99].deleteForce()
LineSegment[90].deleteForce()
lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['4.284',
                      '64.75',
                      '0'],
                 nature=Nature['STANDARD'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['8.67',
                      '64.75',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = PointCoordinates(color=Color['Grey'],
                 visibility=Visibility['VISIBLE'],
                 coordSys=CoordSys['XYZ1'],
                 uvw=['13.056',
                      '64.75',
                      '0'],
                 nature=Nature['STANDARD'],
                 mesh=MeshPoint['AIDED_MESHPOINT'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[50],
                      Point[51]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[51],
                      Point[52]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[52],
                      Point[53]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[53],
                      Point[49]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[27],
                      Point[53]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[19],
                      Point[52]],
            nature=Nature['STANDARD'])

lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[12],
                      Point[51]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

Volume[1,2,3,4,5,6].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[8].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[12].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[13].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

Volume[14,11,10,9,7].assignMeshGenerator(meshGenerator=MeshGenerator['AIDED_MESHGENERATOR'])

FaceAutomatic[44,47].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


FaceAutomatic[45,51,56].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']


deleteMesh()

startMacroTransaction()
Face[30].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']

Face[30].relaxation=RelaxFace['AIDED_RELAXFACE']

Face[30].shadow=ShadowFace['AIDED_SHADOWFACE']

endMacroTransaction()

startMacroTransaction()
Face[36].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']

Face[36].relaxation=RelaxFace['AIDED_RELAXFACE']

Face[36].shadow=ShadowFace['AIDED_SHADOWFACE']

endMacroTransaction()

startMacroTransaction()
Face[37].meshGenerator=MeshGenerator['AIDED_MESHGENERATOR']

Face[37].relaxation=RelaxFace['AIDED_RELAXFACE']

Face[37].shadow=ShadowFace['AIDED_SHADOWFACE']

endMacroTransaction()

meshDomain()

checkMesh()

saveProject()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

deleteMesh()

LineSegment[96].assignMeshLine(meshLine=MeshLine['MESHLINE_15'])

LineSegment[95].assignMeshLine(meshLine=MeshLine['MESHLINE_15'])

LineSegment[94,95,96].assignMeshLine(meshLine=MeshLine['MESHLINE_15'])

LineSegment[78].assignMeshLine(meshLine=MeshLine['MESHLINE_15'])

LineSegment[88,86,89,103,92,85,84,65].assignMeshLine(meshLine=MeshLine['MESHLINE_50'])

meshLines()

deleteMesh()

Line[103].mesh=MeshLine['MESHLINE_15']


meshLines()

deleteMesh()

LineSegment[50,61,62,38,26,37,63,30,52,35,25,29,36,51,47,33,24,27,34,53,48,56,42,57,23,28,39,55].mesh=MeshLine['MESHLINE_2']


LineSegment[102,99,90].mesh=MeshLine['MESHLINE_2']


LineSegment[1,5,10,31,72,80,21,17,44,82,19,14,87,43,7,3].mesh=MeshLine['MESHLINE_15']


LineSegment[94,101,100,98,12,18,40,81].mesh=MeshLine['MESHLINE_8']


LineSegment[4,6,46,58].mesh=MeshLine['MESHLINE_10']


LineSegment[104,105,106,95].mesh=MeshLine['MESHLINE_5']


Line[73,67,69,74,76,75,77,68,71,93,70,66,49,83,81,79].mesh=MeshLine['MESHLINE_2']


Line[97].mesh=MeshLine['MESHLINE_15']


LineSegment[88,92,89,86,85,91,84,65].mesh=MeshLine['MESHLINE_25']


meshDomain()

checkMesh()

deleteMesh()

FaceAutomatic[58,68,53].assignMeshGenerator(meshGenerator=MeshGenerator['MAPPED'])

structureFace(face=Face[68],
              points=[Point[50],
                      Point[49],
                      Point[47],
                      Point[45]])

LineSegment[90,99,102,103].assignMeshLine(meshLine=MeshLine['MESHLINE_10'])

LineSegment[90,99,102].assignMeshLine(meshLine=MeshLine['MESHLINE_2'])

lastInstance = MeshLineArithmetic(name='MeshLine_13',
                   color=Color['Grey'],
                   number=13)

LineSegment[103].assignMeshLine(meshLine=MeshLine['MESHLINE_13'])

deleteMesh()

PointCoordinates[53,52,51].deleteForce()
lastInstance = LineSegment(color=Color['Grey'],
            visibility=Visibility['VISIBLE'],
            defPoint=[Point[50],
                      Point[49]],
            nature=Nature['STANDARD'])

buildFaces()

buildVolumes()

Line[90].mesh=MeshLine['MESHLINE_25']


meshDomain()

deleteMesh()

Face[63].meshGenerator=MeshGenerator['MAPPED']


meshDomain()

Face[63].relaxation=None


deleteMesh()

meshDomain()

deleteMesh()

saveProject()

deleteMesh()

LineSegment[98,100,101].deleteForce()
buildFaces()

buildVolumes()

meshDomain()

Face[44].visibility=Visibility['INVISIBLE']


Face[11].visibility=Visibility['INVISIBLE']


Face[40].visibility=Visibility['INVISIBLE']


Face[60].visibility=Visibility['INVISIBLE']


viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

Face[42].visibility=Visibility['INVISIBLE']


viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

saveProject()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

LineSegment[95,94,78,96,97].visibility=Visibility['INVISIBLE']


viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

saveProject()

lastInstance = ApplicationMagneticAC3D(frequency='60',
                        formulationModel=MagneticACFormulationModelAutomatic(approximation=VectorPotentialApproximationEdge()),
                        scalarVariableOrder=ScalarVariableAutomaticOrder(),
                        vectorNodalVariableOrder=VectorNodalVariableAutomaticOrder(),
                        coilCoefficient=CoilCoefficientAutomatic(),
                        eFieldComputation=EFieldComputationModeWithoutComputation())

checkMesh()

lastInstance = Material(name='FE_SI_M3',
         propertyBH=PropertyBhNonlinearSpline(splinePoints=[BHPoint(h=0.0,
                                                                    b=0.0),
                                                            BHPoint(h=10.0,
                                                                    b=0.82),
                                                            BHPoint(h=10.5,
                                                                    b=0.9),
                                                            BHPoint(h=11.0,
                                                                    b=0.97),
                                                            BHPoint(h=11.25,
                                                                    b=1.0),
                                                            BHPoint(h=11.5,
                                                                    b=1.03),
                                                            BHPoint(h=11.75,
                                                                    b=1.06),
                                                            BHPoint(h=12.0,
                                                                    b=1.08),
                                                            BHPoint(h=12.5,
                                                                    b=1.12),
                                                            BHPoint(h=12.75,
                                                                    b=1.15),
                                                            BHPoint(h=13.25,
                                                                    b=1.18),
                                                            BHPoint(h=13.5,
                                                                    b=1.2),
                                                            BHPoint(h=13.75,
                                                                    b=1.22),
                                                            BHPoint(h=14.0,
                                                                    b=1.24),
                                                            BHPoint(h=14.25,
                                                                    b=1.26),
                                                            BHPoint(h=14.6,
                                                                    b=1.28),
                                                            BHPoint(h=14.9,
                                                                    b=1.3),
                                                            BHPoint(h=15.25,
                                                                    b=1.32),
                                                            BHPoint(h=15.6,
                                                                    b=1.34),
                                                            BHPoint(h=16.0,
                                                                    b=1.36),
                                                            BHPoint(h=16.5,
                                                                    b=1.38),
                                                            BHPoint(h=17.0,
                                                                    b=1.4),
                                                            BHPoint(h=17.5,
                                                                    b=1.42),
                                                            BHPoint(h=18.1,
                                                                    b=1.44),
                                                            BHPoint(h=18.8,
                                                                    b=1.46),
                                                            BHPoint(h=19.6,
                                                                    b=1.48),
                                                            BHPoint(h=20.5,
                                                                    b=1.5),
                                                            BHPoint(h=21.5,
                                                                    b=1.52),
                                                            BHPoint(h=22.8,
                                                                    b=1.54),
                                                            BHPoint(h=24.5,
                                                                    b=1.56),
                                                            BHPoint(h=26.25,
                                                                    b=1.58),
                                                            BHPoint(h=28.5,
                                                                    b=1.6),
                                                            BHPoint(h=30.5,
                                                                    b=1.62),
                                                            BHPoint(h=33.5,
                                                                    b=1.64),
                                                            BHPoint(h=36.5,
                                                                    b=1.66),
                                                            BHPoint(h=40.0,
                                                                    b=1.68),
                                                            BHPoint(h=45.0,
                                                                    b=1.7),
                                                            BHPoint(h=50.0,
                                                                    b=1.72),
                                                            BHPoint(h=58.0,
                                                                    b=1.74),
                                                            BHPoint(h=62.0,
                                                                    b=1.76),
                                                            BHPoint(h=80.0,
                                                                    b=1.78),
                                                            BHPoint(h=98.0,
                                                                    b=1.8),
                                                            BHPoint(h=128.0,
                                                                    b=1.82),
                                                            BHPoint(h=160.0,
                                                                    b=1.84),
                                                            BHPoint(h=220.0,
                                                                    b=1.86),
                                                            BHPoint(h=330.0,
                                                                    b=1.88),
                                                            BHPoint(h=500.0,
                                                                    b=1.9),
                                                            BHPoint(h=775.0,
                                                                    b=1.92),
                                                            BHPoint(h=1400.0,
                                                                    b=1.94),
                                                            BHPoint(h=3000.0,
                                                                    b=1.96),
                                                            BHPoint(h=10000.0,
                                                                    b=1.965)],
                                              equivalentHarmonicCurve=EquivalentBhSinusoidalB()))

lastInstance = Material(name='A36',
         propertyBH=PropertyBhLinear(mur='200'),
         propertyJE=PropertyJeLinear(rho='1.74E-7'))

lastInstance = RegionFace(name='TANK',
           magneticAC3D=MagneticAC3DFaceSurfaceImpedance(material=Material['A36']),
           visibility=Visibility['VISIBLE'])

lastInstance = RegionVolume(name='AIR',
             magneticAC3D=MagneticAC3DVolumeVacuum(),
             visibility=Visibility['VISIBLE'])

lastInstance = RegionVolume(name='CORE',
             magneticAC3D=MagneticAC3DVolumeMagnetic(material=Material['FE_SI_M3']),
             visibility=Visibility['VISIBLE'],
             color=Color['Grey_Steel'])

lastInstance = RegionVolume(name='FRAME',
             magneticAC3D=MagneticAC3DVolumeSurfaceImpedance(material=Material['A36']),
             visibility=Visibility['VISIBLE'])

startMacroTransaction()
RegionVolume['FRAME'].color=Color['Pink_Dark']

RegionVolume['AIR'].visibility=Visibility['INVISIBLE']

RegionVolume['AIR'].color=Color['White']

endMacroTransaction()

exportCircuit(filename='7_log1.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='7_log1.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = CoilCircular(name='HV',
             strandedCoil=CoilConductor['HV'],
             turnNumber='500',
             seriesOrParallel=AllInSeries(),
             coilDuplicationBySymmetriesPeriodicities=CoilDuplication(),
             coordSys=CoordSys['XYZ1'],
             center=['0',
                     '0',
                     '0'],
             radius='24.6875',
             section=ComposedCoilRectangularSection(height='86.8625',
                                                    width='5.5'),
             color=Color['Red'],
             visibility=Visibility['VISIBLE'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

lastInstance = CoilCircular(name='LV',
             strandedCoil=CoilConductor['HV'],
             turnNumber='500',
             seriesOrParallel=AllInSeries(),
             coilDuplicationBySymmetriesPeriodicities=CoilDuplication(),
             coordSys=CoordSys['XYZ1'],
             center=['0',
                     '0',
                     '0'],
             radius='18.6875',
             section=ComposedCoilRectangularSection(height='87.1875',
                                                    width='3.5'),
             color=Color['Red'],
             visibility=Visibility['VISIBLE'])

startMacroTransaction()
Coil['LV'].strandedCoil=CoilConductor['LV']

Coil['LV'].color=Color['Green']

endMacroTransaction()

lastInstance = CoilCircular(name='TV',
             strandedCoil=CoilConductor['TV'],
             turnNumber='104',
             seriesOrParallel=AllInSeries(),
             coilDuplicationBySymmetriesPeriodicities=CoilDuplication(),
             coordSys=CoordSys['XYZ1'],
             center=['0',
                     '0',
                     '0'],
             radius='15.28125',
             section=ComposedCoilRectangularSection(height='95.0625',
                                                    width='1.4375'),
             color=Color['Blue'],
             visibility=Visibility['VISIBLE'])

lastInstance = CoilCircular(name='RV',
             strandedCoil=CoilConductor['RV_1'],
             turnNumber='100',
             seriesOrParallel=AllInParallel(),
             coilDuplicationBySymmetriesPeriodicities=CoilDuplication(),
             coordSys=CoordSys['XYZ1'],
             center=['0',
                     '0',
                     '10.4375'],
             radius='30.6875',
             section=ComposedCoilRectangularSection(height='20.125',
                                                    width='4'),
             color=Color['Magenta'],
             visibility=Visibility['VISIBLE'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=false'])

FaceAutomatic[58,53,63].assignRegion(region=RegionFace['TANK'])

assignRegionToVolumes(volume=[Volume[1],
                              Volume[2],
                              Volume[3],
                              Volume[4],
                              Volume[5],
                              Volume[6],
                              Volume[8],
                              Volume[10],
                              Volume[9]],
                      region=RegionVolume['CORE'])

assignRegionToVolumes(volume=[Volume[7]],
                      region=RegionVolume['AIR'])

assignRegionToVolumes(volume=[Volume[11]],
                      region=RegionVolume['FRAME'])

buildMagneticCircuitCut()

buildMagneticCircuitCut()

result = checkPhysic()

exportCircuit(filename='7_log2.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='7_log2.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

result = checkPhysic()

buildMagneticCircuitCut()

Scenario(name='ReferenceValues')

Scenario['ReferenceValues'].adaptive = InactivatedAdaptive()

Scenario['ReferenceValues'].solve(projectName='C:/Users/ALUMNO/Desktop/VJFC/ATT/ATT/test/7.FLU')

saveProject()

displayIsovalues()

viewGeometry['MAINVIEW'].setProperties(properties=['fullDevice=true'])

PathLine(name='Path_1',
         pathDiscretization=IntervalPathDiscretization(intervalNumber=50),
         regionVolume='CORE',
         color=Color['White'],
         visibility=Visibility['VISIBLE'],
         line=Line[1])


lastInstance = CompoundPath(name='PIERNA_CENTRAL',
             paths=[Path['PATH_1']],
             color=Color['Turquoise'],
             visibility=Visibility['VISIBLE'])

cleanInvalidPaths()

SpatialCurve(name='B_CPC',
             compoundPath=CompoundPath['PIERNA_CENTRAL'],
             formula=['ModV(ModC(B))'])

saveProject()

lastInstance = ComputePhysic(name='ComputePhysic_1', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'PowerS(HV)', 'ModV(ModC(FluxCoil(HV)))/Sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'PowerS(LV)', 'ModV(ModC(FluxCoil(LV)))/Sqrt(2)', 'Mod(U(RV_1))/sqrt(2)', 'Mod(I(RV_1))/sqrt(2)', 'PowerS(RV_1)', 'ModV(ModC(FluxCoil(RV_1)))/Sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'PowerS(TV)', 'ModV(ModC(FluxCoil(TV)))/Sqrt(2)', 'Mod(U(RESISTOR_LOAD))/sqrt(2)', 'Mod(I(RESISTOR_LOAD))/sqrt(2)', 'PowerS(RESISTOR_LOAD)', 'Mod(U(RESISTOR_TV))/sqrt(2)', 'Mod(I(RESISTOR_TV))/sqrt(2)', 'PowerS(RESISTOR_TV)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'Mod(I(VOLTAGESOURCE_1))/sqrt(2)', 'PowerS(VOLTAGESOURCE_1)', 'EMag(S_RSURF_FRAME_CORE)'])

lastInstance = ComputePhysic(name='ComputePhysic_2', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'PowerS(HV)', 'ModV(ModC(FluxCoil(HV)))/Sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'PowerS(LV)', 'ModV(ModC(FluxCoil(LV)))/Sqrt(2)', 'Mod(U(RV_1))/sqrt(2)', 'Mod(I(RV_1))/sqrt(2)', 'PowerS(RV_1)', 'ModV(ModC(FluxCoil(RV_1)))/Sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'PowerS(TV)', 'ModV(ModC(FluxCoil(TV)))/Sqrt(2)', 'Mod(U(RESISTOR_LOAD))/sqrt(2)', 'Mod(I(RESISTOR_LOAD))/sqrt(2)', 'PowerS(RESISTOR_LOAD)', 'Mod(U(RESISTOR_TV))/sqrt(2)', 'Mod(I(RESISTOR_TV))/sqrt(2)', 'PowerS(RESISTOR_TV)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'Mod(I(VOLTAGESOURCE_1))/sqrt(2)', 'PowerS(VOLTAGESOURCE_1)', 'EMag(V_CORE)'])

startMacroTransaction()
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_3'

ComputePhysicTransient['ComputePhysic'].formula=['Mod(U(HV))/sqrt(2)',
                                                 'Mod(I(HV))/sqrt(2)',
                                                 'PowerS(HV)',
                                                 'ModV(ModC(FluxCoil(HV)))/Sqrt(2)',
                                                 'Mod(U(LV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'PowerS(LV)',
                                                 'ModV(ModC(FluxCoil(LV)))/Sqrt(2)',
                                                 'Mod(U(RV_1))/sqrt(2)',
                                                 'Mod(I(RV_1))/sqrt(2)',
                                                 'PowerS(RV_1)',
                                                 'ModV(ModC(FluxCoil(RV_1)))/Sqrt(2)',
                                                 'Mod(U(TV))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)',
                                                 'PowerS(TV)',
                                                 'ModV(ModC(FluxCoil(TV)))/Sqrt(2)',
                                                 'Mod(U(RESISTOR_LOAD))/sqrt(2)',
                                                 'Mod(I(RESISTOR_LOAD))/sqrt(2)',
                                                 'PowerS(RESISTOR_LOAD)',
                                                 'Mod(U(RESISTOR_TV))/sqrt(2)',
                                                 'Mod(I(RESISTOR_TV))/sqrt(2)',
                                                 'PowerS(RESISTOR_TV)',
                                                 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)',
                                                 'Mod(I(VOLTAGESOURCE_1))/sqrt(2)',
                                                 'PowerS(VOLTAGESOURCE_1)',
                                                 'EMag(V_CORE)']

endMacroTransaction()

ComputePhysicTransient['ComputePhysic'].formula=['Mod(U(HV))/sqrt(2)',
                                                 'Mod(I(HV))/sqrt(2)',
                                                 'PowerS(HV)',
                                                 'ModV(ModC(FluxCoil(HV)))/Sqrt(2)',
                                                 'Mod(U(LV))/sqrt(2)',
                                                 'Mod(I(LV))/sqrt(2)',
                                                 'PowerS(LV)',
                                                 'ModV(ModC(FluxCoil(LV)))/Sqrt(2)',
                                                 'Mod(U(RV_1))/sqrt(2)',
                                                 'Mod(I(RV_1))/sqrt(2)',
                                                 'PowerS(RV_1)',
                                                 'ModV(ModC(FluxCoil(RV_1)))/Sqrt(2)',
                                                 'Mod(U(TV))/sqrt(2)',
                                                 'Mod(I(TV))/sqrt(2)',
                                                 'PowerS(TV)',
                                                 'ModV(ModC(FluxCoil(TV)))/Sqrt(2)',
                                                 'Mod(U(RESISTOR_LOAD))/sqrt(2)',
                                                 'Mod(I(RESISTOR_LOAD))/sqrt(2)',
                                                 'PowerS(RESISTOR_LOAD)',
                                                 'Mod(U(RESISTOR_TV))/sqrt(2)',
                                                 'Mod(I(RESISTOR_TV))/sqrt(2)',
                                                 'PowerS(RESISTOR_TV)',
                                                 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)',
                                                 'Mod(I(VOLTAGESOURCE_1))/sqrt(2)',
                                                 'PowerS(VOLTAGESOURCE_1)',
                                                 'EMag(V_CORE)']


lastInstance = ComputePhysic(name='ComputePhysic_3', formula=['Mod(U(HV))/sqrt(2)', 'Mod(I(HV))/sqrt(2)', 'PowerS(HV)', 'ModV(ModC(FluxCoil(HV)))/Sqrt(2)', 'Mod(U(LV))/sqrt(2)', 'Mod(I(LV))/sqrt(2)', 'PowerS(LV)', 'ModV(ModC(FluxCoil(LV)))/Sqrt(2)', 'Mod(U(RV_1))/sqrt(2)', 'Mod(I(RV_1))/sqrt(2)', 'PowerS(RV_1)', 'ModV(ModC(FluxCoil(RV_1)))/Sqrt(2)', 'Mod(U(TV))/sqrt(2)', 'Mod(I(TV))/sqrt(2)', 'PowerS(TV)', 'ModV(ModC(FluxCoil(TV)))/Sqrt(2)', 'Mod(U(RESISTOR_LOAD))/sqrt(2)', 'Mod(I(RESISTOR_LOAD))/sqrt(2)', 'PowerS(RESISTOR_LOAD)', 'Mod(U(RESISTOR_TV))/sqrt(2)', 'Mod(I(RESISTOR_TV))/sqrt(2)', 'PowerS(RESISTOR_TV)', 'Mod(U(VOLTAGESOURCE_1))/sqrt(2)', 'Mod(I(VOLTAGESOURCE_1))/sqrt(2)', 'PowerS(VOLTAGESOURCE_1)', 'EMag(V_CORE)'])

checkMesh()

saveProject()

saveProject()

