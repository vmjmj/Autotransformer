#! Flux3D 22.0
loadProject('C:/Users/victorjimenez/Desktop/Model_Autotrafo/Model_Autotrafo.FLU')

Scenario['REFERENCEVALUES'].delete()
saveProject()

closeProject()

exit()
